public enum TicketType
{
    GENERAL,
    VIP,
    VVIP
}